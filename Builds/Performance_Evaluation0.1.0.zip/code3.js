gdjs.WaitingRoomCode = {};


gdjs.WaitingRoomCode.eventsList0 = function(runtimeScene) {

};

gdjs.WaitingRoomCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.WaitingRoomCode.eventsList0(runtimeScene);

return;

}

gdjs['WaitingRoomCode'] = gdjs.WaitingRoomCode;
