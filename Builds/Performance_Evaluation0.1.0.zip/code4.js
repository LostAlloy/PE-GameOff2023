gdjs.HROfficeCode = {};


gdjs.HROfficeCode.eventsList0 = function(runtimeScene) {

};

gdjs.HROfficeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.HROfficeCode.eventsList0(runtimeScene);

return;

}

gdjs['HROfficeCode'] = gdjs.HROfficeCode;
