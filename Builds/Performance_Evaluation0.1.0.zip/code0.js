gdjs.TitleCode = {};


gdjs.TitleCode.eventsList0 = function(runtimeScene) {

};

gdjs.TitleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.TitleCode.eventsList0(runtimeScene);

return;

}

gdjs['TitleCode'] = gdjs.TitleCode;
